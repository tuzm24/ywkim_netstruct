class ExecFileName(object):
    filename = None